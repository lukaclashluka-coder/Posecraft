# PoseCraft 3D

A Flutter Android/iOS app prototype for artists who need a poseable 3D reference mannequin.

## Included
- Interactive 3D humanoid sample model
- Orbit, zoom and pan camera controls
- Selectable rig joints with X/Y/Z rotation sliders
- Reset pose, front view and side view
- Export changed joint rotations as JSON
- Flutter shell shared by Android and iOS

## Requirements
- Flutter stable SDK (3.3+)
- Android Studio / Android SDK for Android builds
- Xcode on macOS for iOS builds
- Internet connection: Three.js and the sample rigged model are loaded from public CDNs

## Run
From this folder:

```bash
flutter pub get
flutter run
```

Build Android APK:

```bash
flutter build apk --release
```

Build iOS (requires macOS and Xcode):

```bash
flutter build ios --release
```

## Important notes
- This is a working starter app source project, not a signed app-store release. iOS builds/signing require a Mac with Xcode and an Apple developer setup for distribution.
- The bundled HTML loads Three.js and the RobotExpressive sample rig from the internet. For an offline/release version, vendor the Three.js modules and a licensed rigged model locally in `assets/`.
- The sample model is a stylized robot mannequin, chosen as an initial posing reference. Replace the GLB URL in `assets/posecraft.html` with a human model you have rights to use.
- Export currently saves joint rotation values to a JSON file. It does not export a rendered image or a new GLB.
