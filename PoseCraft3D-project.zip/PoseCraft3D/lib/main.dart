import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const PoseCraftApp());

class PoseCraftApp extends StatelessWidget {
  const PoseCraftApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PoseCraft 3D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB5F36B),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF111318),
        useMaterial3: true,
      ),
      home: const PoseCraftHome(),
    );
  }
}

class PoseCraftHome extends StatefulWidget {
  const PoseCraftHome({super.key});

  @override
  State<PoseCraftHome> createState() => _PoseCraftHomeState();
}

class _PoseCraftHomeState extends State<PoseCraftHome> {
  late final WebViewController _controller;
  bool _loading = true;
  String _status = 'Loading 3D studio…';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF111318))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) {
              setState(() {
                _loading = false;
                _status = 'Drag to orbit • Pinch to zoom';
              });
            }
          },
          onWebResourceError: (error) {
            if (mounted) {
              setState(() {
                _status = 'Could not load a 3D resource. Check your internet connection.';
              });
            }
          },
        ),
      )
      ..loadFlutterAsset('assets/posecraft.html');
  }

  Future<void> _run(String action) async {
    await _controller.runJavaScript("window.poseCraftAction('$action');");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.accessibility_new, color: Color(0xFFB5F36B)),
            SizedBox(width: 10),
            Text('PoseCraft 3D', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Reset pose',
            onPressed: () => _run('reset'),
            icon: const Icon(Icons.restart_alt),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  WebViewWidget(controller: _controller),
                  if (_loading)
                    const ColoredBox(
                      color: Color(0xFF111318),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(height: 14),
                            Text('Preparing your posing studio…'),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              color: const Color(0xFF1A1D24),
              child: Row(
                children: [
                  const Icon(Icons.tips_and_updates_outlined,
                      size: 17, color: Color(0xFFB5F36B)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _status,
                      style: const TextStyle(fontSize: 12, color: Colors.white70),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _run('export'),
                    icon: const Icon(Icons.code, size: 17),
                    label: const Text('Pose data'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
